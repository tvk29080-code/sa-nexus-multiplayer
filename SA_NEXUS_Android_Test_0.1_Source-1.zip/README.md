# SA NEXUS — Android Test UI 0.1

This is an Android Studio starter project for the SA NEXUS login/launcher interface.

## Current status
- Login screen UI: included
- Register button: placeholder only
- Connect to server: placeholder only
- Multiplayer server/authentication: NOT implemented
- GTA San Andreas game client: NOT included
- APK: must be built in Android Studio

## Build an APK
1. Install Android Studio on a Windows/Linux/Mac computer.
2. Open this folder as an existing project.
3. Let Gradle sync finish (Android Studio may request an Android SDK platform).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be generated under `app/build/outputs/apk/debug/`.

This prototype does not contain GTA San Andreas files. Use legally obtained game files and licensed assets only.
