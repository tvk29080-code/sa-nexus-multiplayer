package com.sanexus.client;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText username = findViewById(R.id.username);
        EditText password = findViewById(R.id.password);
        TextView status = findViewById(R.id.status);
        Button login = findViewById(R.id.login);
        Button register = findViewById(R.id.register);
        Button connect = findViewById(R.id.connect);

        login.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString();
            if (user.isEmpty() || pass.isEmpty()) {
                status.setText("Enter your username and password.");
            } else {
                status.setText("TEST UI ONLY: account server is not connected yet.");
            }
        });

        register.setOnClickListener(v ->
            status.setText("Registration will be added with the account server.")
        );

        connect.setOnClickListener(v ->
            status.setText("SERVER NOT CONFIGURED: multiplayer connection is not available yet.")
        );
    }
}
