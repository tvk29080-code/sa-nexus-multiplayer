package com.supertounsi.rp;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    EditText username, password;
    int bg=Color.rgb(15,18,25), accent=Color.rgb(210,35,45);
    public void onCreate(Bundle b){super.onCreate(b); login();}
    TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setGravity(17);return t;}
    Button btn(String s){Button x=new Button(this);x.setText(s);x.setTextColor(Color.WHITE);x.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));return x;}
    void base(){root=new LinearLayout(this);root.setOrientation(1);root.setGravity(Gravity.CENTER);root.setPadding(28,24,28,24);root.setBackgroundColor(bg);setContentView(root);}
    void login(){
        base(); root.addView(label("SUPER TOUNSI RP",30));root.addView(label("ROLEPLAY • TUNISIA",14));
        username=new EditText(this);username.setHint("Username");username.setSingleLine();root.addView(username,new LinearLayout.LayoutParams(-1,-2));
        password=new EditText(this);password.setHint("Password");password.setInputType(129);password.setSingleLine();root.addView(password,new LinearLayout.LayoutParams(-1,-2));
        Button go=btn("LOGIN / REGISTER");root.addView(go);go.setOnClickListener(v->{if(username.getText().length()<3||password.getText().length()<4){toast("Username 3+ و Password 4+");return;}home(username.getText().toString());});
        root.addView(label("Prototype v0.1 — Offline UI",12));
    }
    void home(String user){
        base();root.addView(label("أهلا "+user,25));root.addView(label("SUPER TOUNSI • MAIN MENU",16));
        Button play=btn("PLAY (قريباً)");root.addView(play);
        Button admin=btn("ADMIN PANEL");root.addView(admin);admin.setOnClickListener(v->admin());
        Button editor=btn("MAP EDITOR");root.addView(editor);editor.setOnClickListener(v->editor());
        Button logout=btn("LOGOUT");root.addView(logout);logout.setOnClickListener(v->login());
    }
    void admin(){base();root.addView(label("ADMIN PANEL",26));for(String s:new String[]{"Players (قريباً)","Spawn / Teleport (قريباً)","Server Settings (قريباً)","Back"}){Button b=btn(s);root.addView(b);if(s.equals("Back"))b.setOnClickListener(v->login());}}
    void editor(){base();root.addView(label("MAP EDITOR • PREVIEW",24));root.addView(label("Select Object • Move • Rotate • Scale",15));root.addView(label("3D Map tools will be added in next versions",13));Button b=btn("BACK");root.addView(b);b.setOnClickListener(v->login());}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
