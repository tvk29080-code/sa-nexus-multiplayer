# SA NEXUS Android prototype

A small, original, offline top-down city-driving prototype for Android. It is not GTA, does not contain Rockstar assets, and has no online multiplayer/server yet.

## Build
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- Android SDK platform 35

Run `gradle assembleDebug`. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Touch controls: left/right side steer; right-side lower controls accelerate/reverse.
