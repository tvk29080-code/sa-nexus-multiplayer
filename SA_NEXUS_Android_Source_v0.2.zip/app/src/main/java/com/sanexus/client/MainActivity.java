package com.sanexus.client;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        setContentView(new GameView(this));
    }

    static class GameView extends View {
        Paint p = new Paint(3);
        float carX=0, carY=0, speed=0, angle=0;
        boolean up,down,left,right;
        long last=System.nanoTime();
        final int gold=Color.rgb(248,190,48);
        GameView(Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void color(int c){p.setColor(c);p.setStyle(Paint.Style.FILL);}
        void rect(Canvas c,float l,float t,float r,float b,int col){color(col);c.drawRect(l,t,r,b,p);}
        void text(Canvas c,String s,float x,float y,float size,int col,boolean bold){
            color(col);p.setTextSize(size);p.setTypeface(bold?Typeface.create("sans-serif",Typeface.BOLD):Typeface.create("sans-serif",Typeface.NORMAL));c.drawText(s,x,y,p);
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float w=getWidth(),h=getHeight(); if(w==0||h==0)return;
            long now=System.nanoTime(); float dt=Math.min(.04f,(now-last)/1e9f);last=now;
            if(up)speed=Math.min(440,speed+360*dt);
            else if(down)speed=Math.max(-170,speed-420*dt);
            else speed*=Math.pow(.985,dt*60);
            if(left)angle-=2.2f*dt*(.35f+Math.abs(speed)/300f);
            if(right)angle+=2.2f*dt*(.35f+Math.abs(speed)/300f);
            carX+=(float)Math.sin(angle)*speed*dt; carY-=(float)Math.cos(angle)*speed*dt;

            rect(c,0,0,w,h,Color.rgb(55,83,61));
            c.save(); c.translate(w/2-carX,h/2-carY);
            int cell=520;
            int minX=(int)Math.floor((carX-w)/cell), maxX=(int)Math.ceil((carX+w)/cell);
            int minY=(int)Math.floor((carY-h)/cell), maxY=(int)Math.ceil((carY+h)/cell);
            for(int gx=minX;gx<=maxX;gx++) for(int gy=minY;gy<=maxY;gy++){
                float x=gx*cell,y=gy*cell;
                rect(c,x+24,y+24,x+496,y+496,Color.rgb(65,91,65));
                rect(c,x+24,y+24,x+496,y+496,Color.rgb(92,96,91));
                for(int bx=0;bx<3;bx++) for(int by=0;by<3;by++){
                    float xx=x+65+bx*130, yy=y+65+by*130;
                    rect(c,xx,yy,xx+90,yy+82,Color.rgb(116,111,99));
                    rect(c,xx+7,yy+7,xx+83,yy+75,Color.rgb(139,130,111));
                }
                rect(c,x,y,x+520,y+24,Color.rgb(41,43,45));
                rect(c,x,y+496,x+520,y+520,Color.rgb(41,43,45));
                rect(c,x,y,x+24,y+520,Color.rgb(41,43,45));
                rect(c,x+496,y,x+520,y+520,Color.rgb(41,43,45));
                color(Color.rgb(210,190,120));p.setStrokeWidth(3);
                for(int k=0;k<8;k++){float lx=x+50+k*60;c.drawLine(lx,y+10,lx+28,y+10,p);c.drawLine(lx,y+510,lx+28,y+510,p);}
            }
            c.save(); c.rotate((float)Math.toDegrees(angle),w/2,h/2);
            color(Color.BLACK); c.drawRoundRect(w/2-27,h/2-48,w/2+27,h/2+49,12,12,p);
            color(gold); c.drawRoundRect(w/2-23,h/2-44,w/2+23,h/2+45,10,10,p);
            rect(c,w/2-17,h/2-28,w/2+17,h/2+4,Color.rgb(35,52,62));
            rect(c,w/2-17,h/2+12,w/2+17,h/2+31,Color.rgb(35,52,62));
            rect(c,w/2-20,h/2-45,w/2-9,h/2-39,Color.WHITE);
            rect(c,w/2+9,h/2-45,w/2+20,h/2-39,Color.WHITE);
            c.restore(); c.restore();

            rect(c,18,18,250,88,0xCC101116);
            text(c,"SA NEXUS",34,49,23,gold,true);
            text(c,"CITY DRIVE  •  FREE ROAM",34,72,11,Color.WHITE,false);
            rect(c,w-160,18,w-18,78,0xCC101116);
            text(c,String.format(java.util.Locale.US,"%03d KM/H",(int)(Math.abs(speed)*.32f)),w-145,55,20,Color.WHITE,true);
            text(c,"OFFLINE PROTOTYPE",w/2-65,30,11,Color.WHITE,false);
            drawPad(c,70,h-95,"◀",left);drawPad(c,170,h-95,"▶",right);
            drawPad(c,w-180,h-95,"▼",down);drawPad(c,w-80,h-95,"▲",up);
            text(c,"STEER",93,h-154,12,Color.WHITE,true);
            text(c,"DRIVE",w-151,h-154,12,Color.WHITE,true);
            text(c,"Explore the city • Hold ▲ to accelerate",w/2-155,h-22,13,Color.WHITE,false);
            postInvalidateDelayed(16);
        }
        void drawPad(Canvas c,float x,float y,String label,boolean active){
            color(active?0xDDF8BE30:0x99545A62);c.drawCircle(x,y,34,p);
            color(Color.WHITE);p.setTextSize(29);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText(label,x-12,y+10,p);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            float x=e.getX(),y=e.getY();int a=e.getActionMasked();
            if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_MOVE){
                if(x<getWidth()*.42f){left=x<getWidth()*.20f;right=!left;up=false;down=false;}
                else {up=y>getHeight()*.55f&&x>getWidth()*.68f;down=y>getHeight()*.55f&&!up;left=false;right=false;}
            } else if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL){up=down=left=right=false;}
            return true;
        }
    }
}
